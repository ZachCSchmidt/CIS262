package com.example.rp123.soundjukebox;

import android.app.Activity;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.util.SparseIntArray;
import android.view.View;
import android.widget.ImageButton;
import android.widget.MediaController;

public class MyActivity extends Activity {

    // Field Variables

    private ImageButton bellClangBtn;
    private ImageButton funkyGongBtn;
    private ImageButton spookyCryBtn;
    private ImageButton randomHaBtn;
    private ImageButton drumSoloBtn;

    private SoundPool soundPool;
    private SparseIntArray soundMap;

    private MediaPlayer _MediaPlayer;
    private MediaController _MediaController;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);

        configureSounds();
        initializeJukeBoxBtns();
    }

    private void configureSounds()
            // Configure sounds used in the jukebox
            // Preload the first four sounds
    {
        soundPool = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
        soundMap = new SparseIntArray(4);
        soundMap.put(1, soundPool.load(this, R.raw.bell_clang, 1));
        soundMap.put(2, soundPool.load(this, R.raw.funky_gong, 1));
        soundMap.put(3, soundPool.load(this, R.raw.spooky_cry, 1));
        soundMap.put(4, soundPool.load(this, R.raw.random_ha, 1));







        // Fifth Sound Will be played in Media Player
        _MediaPlayer = MediaPlayer.create(this, R.raw.drum);
        _MediaController = new MediaController(this);
        _MediaController.setEnabled(true);

    }

    private void initializeJukeBoxBtns()
    {
        // Set variables to ImageButtons on activity_my.xml
        bellClangBtn = (ImageButton) findViewById(R.id.imageButton);
        funkyGongBtn = (ImageButton) findViewById(R.id.imageButton2);
        spookyCryBtn = (ImageButton) findViewById(R.id.imageButton4);
        randomHaBtn = (ImageButton) findViewById(R.id.imageButton3);
        drumSoloBtn = (ImageButton) findViewById(R.id.imageButton5);

        // Register Listener Events for the Image Buttons
        bellClangBtn.setOnClickListener(playSoundEffect);
        funkyGongBtn.setOnClickListener(playSoundEffect);
        spookyCryBtn.setOnClickListener(playSoundEffect);
        randomHaBtn.setOnClickListener(playSoundEffect);
        drumSoloBtn.setOnClickListener(playSoundEffect);
    }

    private View.OnClickListener playSoundEffect = new View.OnClickListener(){
        public void onClick(View btn){
            // Identify the sound that should be played
            String soundName = (String) btn.getContentDescription();

            // Play the sound based on content description

            if(soundName.contentEquals("Bell Clang"))
            {
                soundPool.play(1, 1, 1, 1, 0, 1.0f);
            }

            else if(soundName.contentEquals("Funky Gong"))
            {
                soundPool.play(2, 1, 1,1, 0, 1.0f);
            }

            else if(soundName.contentEquals("Spooky Cry"))
            {
                soundPool.play(3, 1, 1,1, 0, 1.0f);
            }

            else if(soundName.contentEquals("Random Ha"))
            {
                soundPool.play(4, 1, 1,1, 0, 1.0f);
            }

            else if(soundName.contentEquals("Drum Solo"))
            {
                _MediaController.show();
                _MediaPlayer.start();
            }

        }
    };
}

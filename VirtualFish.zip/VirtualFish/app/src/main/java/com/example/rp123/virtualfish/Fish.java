package com.example.rp123.virtualfish;

/**
 * Created by rp123 on 4/5/2018.
 */

public class Fish {
    // Fish object has a current position that can be accessed publicly
    public int x;
    public int y;

    // Declaring constants
    public static final int IsHungry = 1;
    public static final int IsSwimming = 2;
    public static final int IsEating = 3;


    private int _Condition;
    private int _Velocity;
    private int _StomachCapacity;
    private int _FoodInStomach;
    private int _TankWidth;
    private int _TankHeight;
    private int _Direction;

    private int playX, playY;
    private int foodX, foodY;

    public Fish(int xPos, int yPos, int condition, int tankWidth, int tankHeight)
    {
        _Condition = condition;
        _Velocity = 3;
        _StomachCapacity = 80;
        _FoodInStomach = _StomachCapacity;
        _TankWidth = tankWidth;
        _TankHeight = tankHeight;
        x = xPos;
        y = yPos;
        _Direction = 1;

        // Food and explore locations are set to the top and bottom of the tank
        foodY = (tankHeight / 2 - 100);
        foodX = (int)(Math.ceil(Math.random() * _TankWidth) - _TankWidth / 2);

        playY = (int) -(Math.random() * _TankHeight / 2) + 100;
        playX = (int) (Math.ceil(Math.random() * _TankWidth) - _TankWidth / 2);
    }

    public void move()
    {
        // Switch statement for possible conditions of fish
        switch(_Condition)
        {
            case IsSwimming:
                swim();
                break;
            case IsHungry:
                findFood();
                break;
            case IsEating:
                eatFood();
        }
    }

    private void swim()
    {
        // Burn a calorie of food
        _FoodInStomach--;

        // Swim toward a point of interest: playX, playY
        int xDistance = playX - x;
        int yDistance = playY - y;
        x += xDistance / _Velocity;
        y += yDistance / _Velocity;
        if(playX < x)
        {
            _Direction = -1;
        }
        else{
            _Direction = 1;
        }

        // Find another place to explore in top half of tank
        if(Math.abs(xDistance) < 5 && Math.abs(yDistance) < 5)
        {
            playX = (int) (Math.ceil(Math.random() * _TankWidth) - _TankWidth / 2);
            playY = (int) -(Math.random() * _TankHeight / 2) + 100;
        }

        // Determine if stomach is empty
        if(_FoodInStomach <= 0)
        {
            _Condition = IsHungry;
            // Find a place to eat in the bottom of the tank
            foodX = (int) (Math.ceil(Math.random() * _TankWidth) - _TankWidth / 2) - 100;
        }
    }

    private void findFood()
    {
        // Swim toward food: foodX, foodY
        int xDistance = foodX - x;
        int yDistance = foodY - y;

        x += xDistance / _Velocity;
        y += yDistance / _Velocity;

        if(foodX < x)
        {
            _Direction = -1;
        }
        else{
            _Direction = 1;
        }

        // Determine if food is found
        if(Math.abs((x - foodX)) <= 10 && Math.abs(y - foodY) <= 10)
        {
            _Condition = IsEating;
        }
    }

    private void eatFood()
    {
        // Add a calorie of food to the stomach
        _FoodInStomach += 4;

        // determine if stomach is full
        if(_FoodInStomach >= _StomachCapacity)
        {
            _Condition = IsSwimming;

            // Find a new place to play
            playX = (int) (Math.ceil(Math.random()* _TankWidth) - _TankWidth / 2);
            playY = (int) -(Math.random() * _TankHeight / 2) + 100;
        }

    }

    public int getFacingDirection()
    {
        return _Direction;
    }
}

package com.example.rp123.virtualfish;

import android.app.Activity;
import android.content.Context;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.view.Display;
import android.view.LayoutInflater;
import android.widget.FrameLayout;
import android.widget.ImageView;

public class MyActivity extends Activity {

    // Animation is split into two threads: Calculating Movement and Fish Tank Updates(UI thread)
    private Thread calculateMovementThread;

    // Fish Tank Elements and Properties
    private ImageView fishImageView;
    private Fish _Fish;
    private int tankWidth;
    private int tankHeight;
    private FrameLayout fishTankLayout;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);

        // create references to the frame layout container
        fishTankLayout = findViewById(R.id.container);

        // Get the dimensions of the screen to use for the tank size
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        tankWidth = size.x;
        tankHeight = size.y;

        // Instantiate a fish
        int initialXPos = 0;
        int initialYPos = 0;
        _Fish = new Fish(initialXPos, initialYPos, Fish.IsSwimming, tankWidth, tankHeight);

        // Build the tank elements
        buildTank();

        // Construct the thread to calculate movement and animate the movement
        calculateMovementThread = new Thread(calculateMovement);

        // Start the thread
        calculateMovementThread.start();
    }

    private void buildTank()
    {
        // create a layout inflater to add visual views to the layout
        LayoutInflater layoutInflater;
        layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        // Add the Foliage
        ImageView foliageImageView = (ImageView) layoutInflater.inflate(R.layout.foliage_layout, null);
        foliageImageView.setX((float) 0);
        foliageImageView.setY((float) 0);
        foliageImageView.setAlpha((float) .97);
        fishTankLayout.addView(foliageImageView, 0);

        // Add the virtual fish
        fishImageView = (ImageView) layoutInflater.inflate(R.layout.fish_image, null);
        fishImageView.setScaleX((float) .3);
        fishImageView.setScaleY((float) .3);
        fishImageView.setX(_Fish.x);
        fishImageView.setY(_Fish.y);
        fishTankLayout.addView(fishImageView, 0);
    }

    private Runnable calculateMovement = new Runnable() {
        private static final int DELAY = 200;
        public void run() {
            try
            {
                while(true){
                    _Fish.move();
                    Thread.sleep(DELAY);
                    updateTankHandler.sendEmptyMessage(0);
                }
            }
            catch(InterruptedException e){
                e.printStackTrace();
            }
        }
    };

    public Handler updateTankHandler = new Handler()
    {
        public void handleMessage(android.os.Message msg)
        {
            // Face the fish in the correct direction
            fishImageView.setScaleX((float) (.3 * _Fish.getFacingDirection()));

            // Set the fish at the correct XY Location
            fishImageView.setX((float) _Fish.x);
            fishImageView.setY((float) _Fish.y);
        }
    };

}

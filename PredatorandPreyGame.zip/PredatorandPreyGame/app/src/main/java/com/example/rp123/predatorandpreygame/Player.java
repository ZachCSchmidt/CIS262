package com.example.rp123.predatorandpreygame;

/**
 * Created by rp123 on 4/19/2018.
 */

public class Player {
    // Declare fields
    private int _Row;
    private int _Col;

    public void move(int [] [] gameBoard, String button)
    {
        // If there's no obstacle to the right, then you may move right one cell
        if(button.equals("RIGHT"))
        {
            if(gameBoard[_Row] [_Col + 1] != BoardCodes.isObstacle)
            {
                _Col++;
            }
        }
        // If there's no obstacle to the left, you may move left one cell
        else if(button.equals("LEFT"))
        {
            if(gameBoard[_Row] [_Col - 1] != BoardCodes.isObstacle)
            {
                _Col--;
            }
        }
         // If there's no obstacle upward, you may move up one cell
        else if(button.equals("UP"))
        {
            if(gameBoard[_Row - 1] [_Col] != BoardCodes.isObstacle)
            {
                _Row--;
            }
        }
        // If there's no obstacle downward, you may move down one cell
        else if(button.equals("DOWN"))
        {
           if(gameBoard[_Row + 1] [_Col] != BoardCodes.isObstacle)
           {
               _Row++;
           }
        }
    }

    // Getters and Setters
    public void setRow(int row)
    {
        _Row = row;
    }

    public int getRow()
    {
        return _Row;
    }

    public void setCol(int col)
    {
        _Col = col;
    }

    public int getCol()
    {
        return _Col;
    }

}

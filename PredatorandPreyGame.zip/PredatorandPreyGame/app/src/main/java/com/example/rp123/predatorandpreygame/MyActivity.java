package com.example.rp123.predatorandpreygame;

import android.app.Activity;
import android.content.Context;
import android.media.Image;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.text.Layout;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class MyActivity extends Activity implements GestureDetector.OnDoubleTapListener,
        GestureDetector.OnGestureListener {

    private GestureDetector aGesture;

    // Board Info
    final int SQUARE = 130;
    final int OFFSET = 70;
    final int COLUMNS = 8;
    final int ROWS = 8;
    final int gameBoard[] [] = {
            {1, 1, 1, 1, 1, 1, 1, 1},
            {1, 2, 2, 1, 2, 1, 2, 1},
            {1, 2, 2, 2, 2, 2, 2, 1},
            {1, 2, 1, 2, 2, 2, 2, 1},
            {1, 2, 2, 2, 2, 1, 2, 1},
            {1, 2, 2, 2, 2, 2, 2, 3},
            {1, 2, 1, 2, 2, 2, 2, 1},
            {1, 1, 1, 1, 1, 1, 1, 1}};

    // Visual Objects organized in ArrayList
    private ArrayList<ImageView> visualObjects;
    Player player;
    Enemy enemy;

    // Layout and Interactive Information
    private RelativeLayout constraintLayout;
    private ImageView enemyImg;
    private ImageView playerImg;
    private ImageView obstacleImg;
    private ImageView exitImg;
    private int exitRow;
    private int exitCol;

    // Wins and Losses
    private int wins;
    private int losses;
    private TextView winsTextView;
    private TextView lossesTextView;

    // Declare LayoutInflater
    private LayoutInflater layoutInflater;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);

        // Reference the activity layout and textviews
        constraintLayout = findViewById(R.id.constraintLayout);
        winsTextView = findViewById(R.id.winsTextView);
        lossesTextView = findViewById(R.id.lossesTextView);

        // Instantiate Layout Inflater
        layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        // build the logic board and construct the game
        visualObjects = new ArrayList<ImageView>();
        buildLogicBoard();
        createEnemy();
        createPlayer();
        wins = 0;
        losses = 0;
        winsTextView.setText("Wins: " + wins);
        lossesTextView.setText("Losses: " + losses);

        // Instantiate a Gesture Detector
        aGesture = new GestureDetector(this, this);
        aGesture.setOnDoubleTapListener(this);
    }

    private void buildLogicBoard()
    {
        for(int row = 0; row < ROWS; row++)
        {
            for(int col = 0; col < COLUMNS; col++)
            {
                // If there's an obstacle in that cell show the obstacle image
                if(gameBoard[row] [col] == BoardCodes.isObstacle)
                {
                    obstacleImg = (ImageView) layoutInflater.inflate(R.layout.obstacle_layout, null);
                    obstacleImg.setX(col * SQUARE + OFFSET);
                    obstacleImg.setY(row * SQUARE + OFFSET);
                    constraintLayout.addView(obstacleImg, 0);
                    visualObjects.add(obstacleImg);
                }
                // If the cell is the home cell add the exit image
                else if(gameBoard[row] [col] == BoardCodes.isHome)
                {
                    exitImg = (ImageView) layoutInflater.inflate(R.layout.exit_layout, null);
                    exitImg.setX(col * SQUARE + OFFSET);
                    exitImg.setY(row * SQUARE + OFFSET);
                    constraintLayout.addView(exitImg, 0);
                    visualObjects.add(exitImg);
                    exitRow = 5;
                    exitCol = 7;
                }
            }
        }
    }

    private void createEnemy()
    {
        int row = 2;
        int col = 4;
        enemyImg = (ImageView) layoutInflater.inflate(R.layout.enemy_layout, null);
        enemyImg.setX(col * SQUARE + OFFSET);
        enemyImg.setY(row * SQUARE + OFFSET);
        constraintLayout.addView(enemyImg, 0);

        enemy = new Enemy();
        enemy.setRow(row);
        enemy.setCol(col);
        visualObjects.add(enemyImg);
    }

    private void createPlayer()
    {
        int row = 1;
        int col = 1;

        playerImg = (ImageView) layoutInflater.inflate(R.layout.player_layout, null);
        playerImg.setX(col * SQUARE + OFFSET);
        playerImg.setY(row * SQUARE + OFFSET);
        constraintLayout.addView(playerImg, 0);

        player = new Player();
        player.setRow(row);
        player.setCol(col);
        visualObjects.add(playerImg);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return aGesture.onTouchEvent(event);
    }

    @Override
    public boolean onFling(MotionEvent event1, MotionEvent event2, float velocityX, float velocityY)
    {
        movePlayer(velocityX, velocityY);
        return true;
    }

    @Override
    public void onLongPress(MotionEvent event) {
    }

    @Override
    public void onShowPress(MotionEvent motionEvent) {
    }

    @Override
    public boolean onDown(MotionEvent event) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return true;
    }

    @Override
    public boolean onSingleTapUp(MotionEvent event) {
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent event) {
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent event) {
        return true;
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent event) {
        return true;
    }

    private void movePlayer(float velocityX, float velocityY)
    {
        String direction = "undetectable";

        // Move the player in the fling direction
        if(velocityX > 250)
        {
            direction = "RIGHT";
        }
        else if(velocityX < -250)
        {
            direction = "LEFT";
        }
        else if(velocityY > 250)
        {
            direction = "DOWN";
        }
        else if(velocityY < -250)
        {
            direction = "UP";
        }

        if(!direction.contains("undetectable"))
        {
            player.move(gameBoard, direction);
            playerImg.setX(player.getCol() * SQUARE + OFFSET);
            playerImg.setY(player.getRow() * SQUARE + OFFSET);
            Log.v("Player movement", "row=" + player.getCol() + " col=" + player.getRow());

            // Now it's the enemy's turn to move.
            enemy.move(gameBoard, player.getCol(), player.getRow());
            enemyImg.setX(enemy.getCol() * SQUARE + OFFSET);
            enemyImg.setY(enemy.getRow() * SQUARE + OFFSET);
        }

        // Check if the game is over
        if(enemy.getCol() == player.getCol() && enemy.getRow() == player.getRow())
        {
            losses++;
            lossesTextView.setText("Losses: " + losses);
            startNewGame();
        }

        else if(exitRow == player.getRow() && exitCol == player.getCol())
        {
            wins++;
            winsTextView.setText("Wins: " + wins);
            startNewGame();
        }
    }

    private void startNewGame()
    {
        // Clear the board and remove players
        int howMany = visualObjects.size();
        for(int i = 0; i < howMany; i++)
        {
            ImageView visualObj = visualObjects.get(i);
            constraintLayout.removeView(visualObj);
        }

        visualObjects.clear();

        // Rebuild the board
        buildLogicBoard();

        // Add the players
        createEnemy();
        createPlayer();
    }


}

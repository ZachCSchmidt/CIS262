package com.example.rp123.predatorandpreygame;

/**
 * Created by rp123 on 4/19/2018.
 */

public class BoardCodes {
    // Declare constants
    final static int isObstacle = 1;
    final static int isEmpty = 2;
    final static int isHome = 3;

}

package com.example.rp123.predatorandpreygame;

/**
 * Created by rp123 on 4/19/2018.
 */

public class Enemy {

    // Declare fields
    private int _Row;
    private int _Col;

    public void move(int [] [] gameBoard, int preyCol, int preyRow)
    {
        // If The predator is on a column less than the prey and the cell to the right is empty,
        // the predator may move right
        if(_Col < preyCol && gameBoard[_Row] [_Col + 1] == BoardCodes.isEmpty)
        {
            _Col++;
        }
        // If The predator is on a column greater than the prey and the cell to the left is empty,
        // the predator may move left
        else if(_Col > preyCol && gameBoard[_Row] [_Col - 1] == BoardCodes.isEmpty)
        {
            _Col--;
        }
        // If The predator is on a row less than the prey and the cell below is empty,
        // the predator may move down
        else if(_Row < preyRow && gameBoard[_Row + 1] [_Col] == BoardCodes.isEmpty)
        {
            _Row++;
        }
        // If The predator is on a row less than the prey and the cell above is empty,
        // the predator may move up
        else if(_Row > preyRow && gameBoard[_Row - 1] [_Col] == BoardCodes.isEmpty)
        {
            _Row--;
        }
    }

    public void setRow(int row)
    {
        _Row = row;
    }

    public int getRow()
    {
        return _Row;
    }

    public void setCol(int col)
    {
        _Col = col;
    }

    public int getCol()
    {
        return _Col;
    }
}

package com.example.rp123.unitconversioncalculator;

/**
 * Created by rp123 on 3/8/2018.
 */

public class Conversion {
    // Declare constants
    static final int FEET = 1;
    static final int INCHES = 2;
    static final int POUNDS = 3;
    static final double METERS_PER_FEET = 0.3048;
    static final double CENTIMETERS_PER_INCH = 2.56;
    static final double GRAMS_PER_LB = 453.592;

    private int isA;
    public String inputLabel;
    public String outputLabel;

    public Double inputValue;
    public Double outputValue;

    public Conversion() // constructor method
    {
        // Setting up variables in constructor method
        isA = FEET;

        inputLabel = "FEET";
        outputLabel = "METERS";
        inputValue = 0.0;
        outputValue = 0.0;
    }

    public void change_toFeetMeters()
    {
        isA = FEET;
        inputLabel = "FEET";
        outputLabel = "METERS";
        compute();
    }

    public void change_toInchesCentimeters()
    {
        isA = INCHES;
        inputLabel = "INCHES";
        outputLabel = "CENTIMETERS";
        compute();
    }

    public void change_toPoundsGrams()
    {
        isA = POUNDS;
        inputLabel = "POUNDS";
        outputLabel = "GRAMS";
        compute();
    }

    public void compute()
    {
        if(isA == FEET)
        {
            outputValue = inputValue * METERS_PER_FEET;
        }

        else if(isA == INCHES)
        {
            outputValue = inputValue * CENTIMETERS_PER_INCH;
        }
        else if(isA == POUNDS)
        {
            outputValue = inputValue * GRAMS_PER_LB;
        }

        else
        {
            outputValue = 0.0;
        }
    }
}

package com.example.rp123.mazechase;

/**
 * Created by rp123 on 3/22/2018.
 */

public class MazeCell {
    public int x;
    public int y;
    public int id;
    public boolean visited;
    public boolean north;
    public boolean south;
    public boolean east;
    public boolean west;

    // New Cells Instantiated with All Walls Intact

    // Constructor Method
    public MazeCell(int xPos, int yPos, int cellId)
    {
        x = xPos;
        y = yPos;
        visited = false;
        north = true;
        south = true;
        east = true;
        west = true;
    }
}

package com.example.rp123.mazechase;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

import java.util.Stack;

/**
 * Created by rp123 on 3/22/2018.
 */

public class MazeCanvas extends View {

    // Maze Dimensions

    // Constant Variables
    public final int COLS = 10;
    public final int ROWS = 9;
    final int N_CELLS = COLS * ROWS;
    final int SIZE = 100;
    final int OFFSET = 100;

    // Array of Maze Cells

    public  MazeCell [] board;

    private Paint paint;

    public MazeCanvas(Context context)
    {
        super(context);

        // Declare a Maze Array of Size N_Cells to hold the cells
        board = new MazeCell[N_CELLS];

        // Instantiate Cell Objects for Each Cell in the Maze
        int cellId = 0;
        for(int r = 0; r < ROWS; r++)
        {
            for(int c =0; c < COLS; c++)
            {
                // Generate a Maze Cell with the X, Y and Cell ID
                int x = c * SIZE + OFFSET;
                int y = r * SIZE + OFFSET;
                MazeCell cell = new MazeCell(x, y, cellId);

                // Place the Cell in the Maze
                board[cellId] = cell;
                cellId++;
            }
        }

        // Set the Paint for the Maze
        paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setStrokeWidth(2.0f);

        // Use a BackTracker Method to Break Down the Walls
        backtrackMaze();
    }

    public void onDraw(Canvas canvas)
    {
        // Fill the Canvas with White Paint
        canvas.drawRGB(255, 255, 255);

        // Draw the Lines for Every Cell
        for(int i = 0; i < N_CELLS; i++)
        {
            int x = board[i].x;
            int y = board[i].y;

            if(board[i].north)
                canvas.drawLine(x, y, x+SIZE, y, paint);
            if(board[i].south)
                canvas.drawLine(x, y+SIZE, x+SIZE, y+SIZE, paint);
            if(board[i].east)
                canvas.drawLine(x+SIZE, y, x+SIZE, y+SIZE, paint);
            if(board[i].west)
                canvas.drawLine(x, y, x, y+SIZE, paint);

        }
    }

    public void backtrackMaze()
    {
        // Create Backtracker Variables
        Stack<Integer> stack = new Stack<Integer>();
        int top;

        // Visit first Cell and push it onto the stack
        int visitedCells = 1; // Counts how many cells have been visited
        int cellID = 0; // First Cell in the Maze
        board[cellID].visited = true;
        stack.push(cellID);

        // Backtrack until all the cells have been visited
        while(visitedCells < N_CELLS)
        {
            // Determine which walls can be taken down for a given cell
            String possibleWalls = "";
            if(board[cellID].north == true && cellID >= COLS)
            {
                if(!board[cellID - COLS].visited)
                {
                    possibleWalls += "N";
                }
            }
            if(board[cellID].west == true && cellID % COLS != 0)
            {
                if(!board[cellID - 1].visited)
                {
                    possibleWalls += "W";
                }
            }
            if(board[cellID].east == true && cellID % COLS != COLS - 1)
            {
                if(!board[cellID + 1].visited)
                {
                    possibleWalls += "E";
                }
            }
            if(board[cellID].south == true && cellID < COLS * ROWS - COLS)
            {
                if(!board[cellID + COLS].visited)
                {
                    possibleWalls += "S";
                }
            }

            // Select a Random Wall from Available Walls
            if(possibleWalls.length() > 0)
            {
                int index = Math.round((int) (Math.random() * possibleWalls.length()));
                char randomWall = possibleWalls.charAt(index);

                switch(randomWall)
                {
                    case 'N':
                        board[cellID].north = false;
                        board[cellID - COLS].south = false;
                        cellID -= COLS;
                        break;

                    case'S':
                        board[cellID].south = false;
                        board[cellID + COLS].north = false;
                        cellID += COLS;
                        break;

                    case'E':
                        board[cellID].east = false;
                        board[cellID + 1].west = false;
                        cellID++;
                        break;

                    case'W':
                        board[cellID].west = false;
                        board[cellID - 1].east = false;
                        cellID--;
                        break;
                }
                board[cellID].visited = true;
                stack.push(cellID);
                visitedCells++;
            }
            // If there are no walls to bust down backtrack by grabbing the top of the stack
            else{
                top = stack.pop();
                if(top == cellID)
                {
                    cellID = stack.pop();
                    stack.push(cellID);
                }
            }

        }
    }

}

package com.example.rp123.mazechase;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class MyActivity extends Activity {

    // Field Level Variables

    private RelativeLayout relativeLayout;
    private ImageView pig;
    private LayoutInflater layoutInflater;
    private float xPos;
    private float yPos;
    private MazeCanvas maze;

    private int cellId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);
        xPos = 10;
        yPos = 10;
        cellId = 22;

        // Constructing the Maze and adding it to the Constraint Layout
        maze = new MazeCanvas(this);
        relativeLayout = (RelativeLayout) findViewById(R.id.relativeLayout);
        relativeLayout.addView(maze, 0);

        // Create a Layout Inflater
        layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        // Set background of the ImageView to pig animation
        pig = (ImageView) layoutInflater.inflate(R.layout.pig_view, null);
        pig.setBackgroundResource(R.anim.pig_animation);

        // Create an Animation Drawable Object Based on This Background
        AnimationDrawable pigAnimate = (AnimationDrawable) pig.getBackground();
        pigAnimate.start();

        pig.setX(xPos);
        pig.setY(yPos);
        pig.setScaleX(.15f);
        pig.setScaleY(.15f);
        relativeLayout.addView(pig, 1);
    }

    public void goUp(View view)
    {
        if(maze.board[cellId].north == false)
        {
            yPos -= 100;
            pig.setY(yPos);
            cellId -= maze.COLS;
        }
    }

    public void goLeft(View view)
    {
        if(maze.board[cellId].west == false)
        {
            xPos -= 100;
            pig.setX(xPos);
            cellId --;
        }
    }

    public void goRight(View view)
    {
        if(maze.board[cellId].east == false)
        {
            xPos += 100;
            pig.setX(xPos);
            cellId ++;
        }
    }

    public void goDown(View view)
    {
        if(maze.board[cellId].south == false)
        {
            yPos += 100;
            pig.setY(yPos);
            cellId += maze.COLS;
        }
    }
}

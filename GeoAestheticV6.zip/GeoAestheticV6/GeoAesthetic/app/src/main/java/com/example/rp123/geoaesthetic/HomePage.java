package com.example.rp123.geoaesthetic;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

/**
 * Created by rp123 on 4/30/2018.
 */

public class HomePage extends Activity {


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_screen);

    }

    public void showPictures(View view)
    {
        Intent intent = new Intent(this, PictureSlideShow.class);

        switch(view.getId()) {
            case R.id.carrington:
                // This is where you will put the code
                // For the scrollview to pop up when the imagebutton is clicked.
                intent.putExtra("pictureId", R.id.carrington);
                startActivity(intent);
                break;
            case R.id.psu:
                // This is where you will put the code
                // For the scrollview to pop up when the imagebutton is clicked.
                intent.putExtra("pictureId", R.id.psu);
                startActivity(intent);
                break;

            case R.id.glass_hall:
                // This is where you will put the code
                // For the scrollview to pop up when the imagebutton is clicked.
                intent.putExtra("pictureId", R.id.glass_hall);
                startActivity(intent);
                break;

            case R.id.jqh:
                // This is where you will put the code
                // For the scrollview to pop up when the imagebutton is clicked.
                intent.putExtra("pictureId", R.id.jqh);
                startActivity(intent);
                break;

            case R.id.library:
                // This is where you will put the code
                // For the scrollview to pop up when the imagebutton is clicked.
                intent.putExtra("pictureId", R.id.library);
                startActivity(intent);
                break;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction() == MotionEvent.ACTION_DOWN)
        {
            toggleActionBar();
        }
        return true;
    }

    private void toggleActionBar()
    {
        ActionBar actionBar = getActionBar();

        if(actionBar != null)
        {
            if(actionBar.isShowing())
            {
                actionBar.hide();
            }
            else
            {
                actionBar.show();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.geo_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if(id == R.id.menuitem_quit)
        {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }
}

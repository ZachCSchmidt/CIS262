package com.example.rp123.geoaesthetic;

/**
 * Created by ricky_000 on 5/2/2018.
 */

public class Pictures {

    public static String carringtonDesc[] = {"Front of Carrington Hall", "Carrington Hall Classroom (Front)", "Carrington Hall Aerial View", "Carrington Hall Classroom (Back)"};

    public static int carringtonPicId [] = {R.drawable.carrington1,
                                            R.drawable.carrington2,
                                            R.drawable.carrington3,
                                            R.drawable.carrington4};
    public static String psuDesc [] = {"Bowling Area", "PSU Night", "Dining Area", "PSU Front Desk"};

    public static int psuPicId [] = {R.drawable.psu1,
                                     R.drawable.psu2,
                                     R.drawable.psu3,
                                     R.drawable.psu4};

    public static String glassHallDesc [] = {"Glass Hall Afternoon", "Glass Hall Day", "Glass Hall Night", "Glass Hall Interior"};

    public static int glassHallPicId [] = {R.drawable.glass1,
                                           R.drawable.glass2,
                                           R.drawable.glass3,
                                           R.drawable.glass4};

    public static String jqhDesc [] = {"Basketball Stadium", "JQH Night", "Basketball Stadium Occupied", "Seating Area"};

    public static int jqhPicId [] = {R.drawable.jqh1,
                                     R.drawable.jqh2,
                                     R.drawable.jqh3,
                                     R.drawable.jqh4};

    public static String libraryDesc [] = {"Library Fountain", "Fountain and Clock Tower Day", "Study Area", "Fountain and Clock Tower Night"};

    public static int libraryPicId [] = {R.drawable.library1,
                                         R.drawable.library2,
                                         R.drawable.library3,
                                         R.drawable.library4};




}

package com.example.rp123.geoaesthetic;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

    private EditText userNameET;
    private EditText passwordET;
    private Button loginButton;
    int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setUpUIReferences();

        userNameET.requestFocus();


        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(userNameET.getText().toString().equals("admin") &&
                        passwordET.getText().toString().equals("admin"))
                {
                    Toast.makeText(getApplicationContext(),
                            "Redirecting...",Toast.LENGTH_SHORT).show();
                    count = 0;

                   goToHomeScreen();

                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Invalid UserName or Password",Toast.LENGTH_SHORT).show();
                    count++;
                }

                if(count > 3)
                {
                    loginButton.setEnabled(false);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            loginButton.setEnabled(true);
                            loginButton.setClickable(true);
                        }

                    }, 10000);

                }

            }


            });
        }

    @Override
    protected void onResume() {
        super.onResume();
        userNameET.setText("");
        passwordET.setText("");
        userNameET.requestFocus();
    }

    private void goToHomeScreen()
        {
            Intent intent = new Intent(this, HomePage.class);
            startActivity(intent);
        }

        private void setUpUIReferences()
        {
            userNameET = findViewById(R.id.userNameET);
            passwordET = findViewById(R.id.passwordET);
            loginButton = findViewById(R.id.loginButton);
        }


}

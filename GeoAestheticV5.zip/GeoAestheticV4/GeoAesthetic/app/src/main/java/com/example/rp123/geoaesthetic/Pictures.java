package com.example.rp123.geoaesthetic;

/**
 * Created by ricky_000 on 5/2/2018.
 */

public class Pictures {

    public static String carringtonDesc[] = {"", "", "", ""};

    public static int carringtonPicId [] = {R.drawable.carrington1,
                                            R.drawable.carrington2,
                                            R.drawable.carrington3,
                                            R.drawable.carrington4};
    public static String psuDesc [] = {"", "", "", ""};

    public static int psuPicId [] = {R.drawable.psu1,
                                     R.drawable.psu2,
                                     R.drawable.psu3,
                                     R.drawable.psu4};

    public static String glassHallDesc [] = {"", "", "", ""};

    public static int glassHallPicId [] = {R.drawable.glass1,
                                           R.drawable.glass2,
                                           R.drawable.glass3,
                                           R.drawable.glass4};

    public static String jqhDesc [] = {"", "", "", ""};

    public static int jqhPicId [] = {R.drawable.jqh1,
                                     R.drawable.jqh2,
                                     R.drawable.jqh3,
                                     R.drawable.jqh4};

    public static String libraryDesc [] = {"", "", "", ""};

    public static int libraryPicId [] = {R.drawable.library1,
                                         R.drawable.library2,
                                         R.drawable.library3,
                                         R.drawable.library4};




}

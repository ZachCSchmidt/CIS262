package com.example.rp123.geoaesthetic;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by rp123 on 5/3/2018.
 */

public class PictureSlideShow extends Activity{

    private LinearLayout pictureSlideshow;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.picture_slideshow);


        pictureSlideshow = (LinearLayout) findViewById(R.id.linearLayout);
        //initializeVariables();

        Intent intent = getIntent();

        int pictureId = intent.getIntExtra("pictureId", R.id.carrington);

        startSlideShow(pictureId);
    }

    private void startSlideShow(int id)
    {

        //initializeObjects();

        ImageButton clickablePics;


        for(int i = 0; i < Pictures.carringtonDesc.length; i++)
        {
            // Use the code from the fillPaintGallery Method as reference for this part
            clickablePics = new ImageButton(this);
            if(id == R.id.carrington)
            {
                PicturesGetSet picturesObj = new PicturesGetSet(Pictures.carringtonDesc[i], Pictures.carringtonPicId[i]);

                // Use the content description property to store pictures data
                clickablePics.setContentDescription(picturesObj.getDescription());

                // Load picture using its ID

                clickablePics.setImageDrawable(getResources().getDrawable(picturesObj.getId()));

                // Set onclick listener for the image button
                clickablePics.setOnClickListener(displayPictureInfo);

                // Add clickablePics to the scrollable linear list.
                pictureSlideshow.addView(clickablePics);
            }

            else if(id == R.id.psu)
            {
                PicturesGetSet picturesObj = new PicturesGetSet(Pictures.psuDesc[i], Pictures.psuPicId[i]);

                // Use the content description property to store pictures data
                clickablePics.setContentDescription(picturesObj.getDescription());

                // Load picture using its ID

                clickablePics.setImageDrawable(getResources().getDrawable(picturesObj.getId()));

                // Set onclick listener for the image button
                clickablePics.setOnClickListener(displayPictureInfo);

                // Add clickablePics to the scrollable linear list.
                pictureSlideshow.addView(clickablePics);
            }

            else if(id == R.id.glass_hall)
            {
                PicturesGetSet picturesObj = new PicturesGetSet(Pictures.glassHallDesc[i], Pictures.glassHallPicId[i]);

                // Use the content description property to store pictures data
                clickablePics.setContentDescription(picturesObj.getDescription());

                // Load picture using its ID

                clickablePics.setImageDrawable(getResources().getDrawable(picturesObj.getId()));

                // Set onclick listener for the image button
                clickablePics.setOnClickListener(displayPictureInfo);

                // Add clickablePics to the scrollable linear list.
                pictureSlideshow.addView(clickablePics);
            }

            else if(id == R.id.jqh)
            {
                PicturesGetSet picturesObj = new PicturesGetSet(Pictures.jqhDesc[i], Pictures.jqhPicId[i]);

                // Use the content description property to store pictures data
                clickablePics.setContentDescription(picturesObj.getDescription());

                // Load picture using its ID

                clickablePics.setImageDrawable(getResources().getDrawable(picturesObj.getId()));

                // Set onclick listener for the image button
                clickablePics.setOnClickListener(displayPictureInfo);

                // Add clickablePics to the scrollable linear list.
                pictureSlideshow.addView(clickablePics);
            }

            else if(id == R.id.library)
            {
                PicturesGetSet picturesObj = new PicturesGetSet(Pictures.libraryDesc[i], Pictures.libraryPicId[i]);

                // Use the content description property to store pictures data
                clickablePics.setContentDescription(picturesObj.getDescription());

                // Load picture using its ID

                clickablePics.setImageDrawable(getResources().getDrawable(picturesObj.getId()));

                // Set onclick listener for the image button
                clickablePics.setOnClickListener(displayPictureInfo);

                // Add clickablePics to the scrollable linear list.
                pictureSlideshow.addView(clickablePics);
            }
        }
    }

    private View.OnClickListener displayPictureInfo = new View.OnClickListener()
    {
        public void onClick(View btn)
        {
            // Get information stored about picture
            String pictureDescription = (String) btn.getContentDescription();

            // Make method call to display info
            displayToast(pictureDescription);
        }
    };

    private void displayToast(String _pictureDescription)
    {
        Toast.makeText(this, _pictureDescription, Toast.LENGTH_SHORT).show();
    }
}

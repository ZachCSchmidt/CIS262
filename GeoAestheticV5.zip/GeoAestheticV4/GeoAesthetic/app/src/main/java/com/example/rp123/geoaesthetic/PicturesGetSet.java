package com.example.rp123.geoaesthetic;

/**
 * Created by ricky_000 on 5/2/2018.
 */

public class PicturesGetSet {

    private String _Description;

    private int _Id;

    public PicturesGetSet(String description, int id)
    {
        _Description = description;
        _Id = id;
    }

    public void setDescription(String description)
    {
        _Description = description;
    }

    public String getDescription()
    {
        return _Description;
    }

    public void setId(int id)
    {
        _Id = id;
    }

    public int getId()
    {
        return _Id;
    }



}

package com.example.rp123.geoaesthetic;

import android.app.ActionBar;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;

/**
 * Created by rp123 on 4/30/2018.
 */

public class HomePage extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_screen);
    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction() == MotionEvent.ACTION_DOWN)
        {
            toggleActionBar();
        }
        return true;
    }

    private void toggleActionBar()
    {
        ActionBar actionBar = getActionBar();

        if(actionBar != null)
        {
            if(actionBar.isShowing())
            {
                actionBar.hide();
            }
            else
            {
                actionBar.show();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.geo_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if(id == R.id.menuitem_quit)
        {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }
}

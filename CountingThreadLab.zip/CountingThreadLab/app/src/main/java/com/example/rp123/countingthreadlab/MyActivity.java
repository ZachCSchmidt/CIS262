package com.example.rp123.countingthreadlab;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

public class MyActivity extends Activity {

    // Field Level Variables
    private TextView countTextView;
    private Integer count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);

        // Set variable to Textview in layout file
        countTextView = findViewById(R.id.textView);

        // Initialize Counter
        count = 0;

        // Create a thread and start the thread
        Thread thread = new Thread(countNumbers);
        thread.start();

    }

    // Initialize Counter to zero each time the application launches
    @Override
    protected void onStart() {
        super.onStart();
        count = 0;
    }

    // Create Runnable
    private Runnable countNumbers = new Runnable()
    {
        private static final int DELAY = 1000;
        public void run()
        {
            try
            {
                while(true)
                {
                    count++;
                    Thread.sleep(DELAY);
                    threadHandler.sendEmptyMessage(0);
                }

            }
            catch(InterruptedException e)
            {
                e.printStackTrace();
            }
        }
    };

    // Create Handler
    public Handler threadHandler = new Handler() // Handler Updates UI elements
    {
        public void handleMessage(android.os.Message message)
        {
            countTextView.setText(count.toString());
        }
    };


}

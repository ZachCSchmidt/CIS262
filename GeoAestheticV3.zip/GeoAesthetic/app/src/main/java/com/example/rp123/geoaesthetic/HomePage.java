package com.example.rp123.geoaesthetic;

import android.app.ActionBar;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;

/**
 * Created by rp123 on 4/30/2018.
 */

public class HomePage extends Activity {

    // Declare Fields
    private ImageButton bearStatue;
    private ImageButton psu;
    private ImageButton glassHall;
    private ImageButton welcomeCenter;
    private ImageButton footballStadium;
    private ImageButton classroomLecture;

    private LinearLayout pictureSlideshow;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_screen);

        initializeVariables();
    }

    public void showPictures(View view)
    {
        switch(view.getId()) {
            case R.id.bearStatue:
                // This is where you will put the code
                // For the scrollview to pop up when the imagebutton is clicked.
                setContentView(R.layout.picture_slideshow);
                startSlideShow();
                break;
            case R.id.psu:
                // This is where you will put the code
                // For the scrollview to pop up when the imagebutton is clicked.
                setContentView(R.layout.picture_slideshow);
                startSlideShow();
                break;

            case R.id.glass_hall:
                // This is where you will put the code
                // For the scrollview to pop up when the imagebutton is clicked.
                setContentView(R.layout.picture_slideshow);
                startSlideShow();
                break;

            case R.id.welcome_center:
                // This is where you will put the code
                // For the scrollview to pop up when the imagebutton is clicked.
                setContentView(R.layout.picture_slideshow);
                startSlideShow();
                break;

            case R.id.football_stadium:
                // This is where you will put the code
                // For the scrollview to pop up when the imagebutton is clicked.
                setContentView(R.layout.picture_slideshow);
                startSlideShow();
                break;

            case R.id.classroom_lecture:
                // This is where you will put the code
                // For the scrollview to pop up when the imagebutton is clicked.
                setContentView(R.layout.picture_slideshow);
                startSlideShow();
                break;
        }
    }

    private void startSlideShow()
    {


        ImageButton clicablePics;

        for(int i = 0; i < Pictures.psuDesc.length; i++)
        {
            // Use the code from the fillPaintGallery Method as reference for this part
            clicablePics = new ImageButton(this);
        }
    }



    private void initializeVariables()
    {
        bearStatue =  findViewById(R.id.bearStatue);
        psu = findViewById(R.id.psu);
        glassHall = findViewById(R.id.glass_hall);
        welcomeCenter = findViewById(R.id.welcome_center);
        footballStadium = findViewById(R.id.football_stadium);
        classroomLecture = findViewById(R.id.classroom_lecture);
        pictureSlideshow = findViewById(R.id.linearLayout);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction() == MotionEvent.ACTION_DOWN)
        {
            toggleActionBar();
        }
        return true;
    }

    private void toggleActionBar()
    {
        ActionBar actionBar = getActionBar();

        if(actionBar != null)
        {
            if(actionBar.isShowing())
            {
                actionBar.hide();
            }
            else
            {
                actionBar.show();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.geo_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if(id == R.id.menuitem_quit)
        {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }
}

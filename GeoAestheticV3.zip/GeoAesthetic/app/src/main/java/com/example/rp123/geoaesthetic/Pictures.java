package com.example.rp123.geoaesthetic;

/**
 * Created by ricky_000 on 5/2/2018.
 */

public class Pictures {

    public static String bearStatueDesc[] = {"", "", "", ""};

    public static int bearStatuePicId [] = {// This is where you'll put the Ids of each
            // picture using R.id.whatever the id name is. Look at part 5 of the Renaissance
            // App for guidance
             };
    public static String psuDesc [] = {"", "", "", ""};

    public static int psuPicId [] = {};

    public static String glassHallDesc [] = {"", "", "", ""};

    public static int glassHallPicId [] = {};

    public static String welcomeCenterDesc [] = {"", "", "", ""};

    public static int welcomeCenterId [] = {};

    public static String classRoomLectureDesc [] = {"", "", "", ""};

    public static int classRoomLectureId [] = {};




}

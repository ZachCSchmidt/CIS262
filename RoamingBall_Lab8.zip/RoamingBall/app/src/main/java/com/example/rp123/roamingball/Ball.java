package com.example.rp123.roamingball;

/**
 * Created by rp123 on 5/3/2018.
 */

public class Ball {

    // Declare Fields
    private float _X;
    private float _Y;
    private int _Width;
    private float _VelocityX;
    private float _VelocityY;

    // Getters and Setters

    public void setX(float x)
    {
        _X = x;
    }

    public float getX()
    {
        return _X;
    }

    public void setY(float y)
    {
        _Y = y;
    }

    public float getY()
    {
        return _Y;
    }

    public void setWidth(int width)
    {
        _Width = width;
    }

    public int getWidth()
    {
        return _Width;
    }

    public void setVelocityX(float velocityX)
    {
        _VelocityX = velocityX;
    }

    public float getVelocityX()
    {
        return _VelocityX;
    }

    public void setVelocityY(float velocityY)
    {
        _VelocityY = velocityY;
    }

    public float getVelocityY()
    {
        return _VelocityY;
    }
}

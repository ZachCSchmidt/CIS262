package com.example.rp123.roamingball;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.support.constraint.ConstraintLayout;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MyActivity extends Activity implements SensorEventListener {

    // Declare fields
    private SensorManager sensorManager;
    private Sensor sensorAccelerometer;

    private LayoutInflater layoutInflater;
    private ConstraintLayout mainLayout;
    private ImageView ballImage;
    private Ball _Ball;

    private Thread movementThread;

    static int TOP;
    static int BOTTOM;
    static int LEFT;
    static int RIGHT;

    private TextView x_axis;
    private TextView y_axis;
    private TextView z_axis;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);

         // Set References to layouts
        mainLayout = findViewById(R.id.constraintLayout);
        x_axis = findViewById(R.id.textView2);
        y_axis = findViewById(R.id.textView4);
        z_axis = findViewById(R.id.textView6);

        // Add the ball and initialize movement settings
        _Ball = new Ball();  // Ball object
        initializeBall();
        layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        ballImage = (ImageView) layoutInflater.inflate(R.layout.ball_item, null);
        ballImage.setX(50.0f);
        ballImage.setY(50.0f);
        mainLayout.addView(ballImage, 0);

        // register sensor manager
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sensorAccelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        // Implement movement thread
        movementThread = new Thread(BallMovement);
    }

    private void initializeBall()
    {
        // Compute the width and height of the device
        DisplayMetrics metrics = this.getResources().getDisplayMetrics();
        int screenWidth = metrics.widthPixels;
        int screenHeight = metrics.heightPixels;

        // Configure the Roaming Ball
        _Ball.setX(50.0f);
        _Ball.setY(50.0f);
        _Ball.setWidth(225);

        _Ball.setVelocityX(0.0f);
        _Ball.setVelocityY(0.0f);

        TOP = 0;
        BOTTOM = screenHeight - _Ball.getWidth();
        LEFT = 0;
        RIGHT = screenWidth - _Ball.getWidth();
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, sensorAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);

        movementThread.start();
    }

    // Unregister the listener


    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this, sensorAccelerometer);
    }

    @Override
    protected void onStop() {
        super.onStop();
        finish();
    }

    @Override
    protected void onDestroy() {
        finish();
        super.onDestroy();
    }

    public void onSensorChanged(SensorEvent sensorEvent)
    {
        if(sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER)
        {
            _Ball.setVelocityX(sensorEvent.values[0]);
            _Ball.setVelocityY(sensorEvent.values[1]);

            x_axis.setText(" " + sensorEvent.values[0]);
            y_axis.setText(" " + sensorEvent.values[1]);
            z_axis.setText(" " + sensorEvent.values[2]);
        }
    }

    public void onAccuracyChanged(Sensor arg0, int arg1)
    {
    }
        // Updates the ball position continuously
        private Runnable BallMovement = new Runnable() {
            private static final int DELAY = 20;
            @Override
            public void run() {
                try{
                    while(true)
                    {
                        _Ball.setX(_Ball.getX() - _Ball.getVelocityX());
                        _Ball.setY(_Ball.getY() - _Ball.getVelocityY());

                        // Check for collisions
                        if(_Ball.getY() < TOP)
                            _Ball.setY(TOP);
                        else if(_Ball.getY() > BOTTOM)
                            _Ball.setY(BOTTOM);

                        if(_Ball.getX() < LEFT)
                            _Ball.setX(LEFT);
                        else if(_Ball.getX() > RIGHT)
                            _Ball.setX(RIGHT);

                        // Delay Between Animations
                        Thread.sleep(DELAY);

                        // Handle the relocation of the view (Imageview)
                        threadHandler.sendEmptyMessage(0);


                    }
                } catch(InterruptedException e)
                {
                    e.printStackTrace();
                }
            }
        };

        public Handler threadHandler = new Handler()
        {
            public void handleMessage(android.os.Message msg)
            {
                // Handle the relocation of the ImageView
                ballImage.setX(_Ball.getX());
                ballImage.setY(_Ball.getY());
            }
        };

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }
}

package com.example.rp123.compass_lab8;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;

public class MyActivity extends Activity implements SensorEventListener{

    // Compass Image on the Screen
    private ImageView compassImage;

    // Record the Compass Angle in Degrees
    private float currentDegree = 0.0f;

    // Sensor Managet and the Sensors that will be monitored
    private SensorManager _SensorManager;
    private Sensor sensorAccelerometer;
    private Sensor sensorMagnetometer;

    private float[] accelerometer;
    private float[] geomagnetic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);

        // Reference Compass Image
        compassImage = findViewById(R.id.imageView);

        // Initialize The Sensor Capabilities
        _SensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sensorAccelerometer = _SensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorMagnetometer = _SensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Sensor Delay Game is the only one that works
        _SensorManager.registerListener(this, sensorAccelerometer, SensorManager.SENSOR_DELAY_GAME);
        _SensorManager.registerListener(this, sensorMagnetometer, SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    protected void onPause() {
        super.onPause();
        _SensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        // Rotation Animation is set for 1000 milliseconds
        final int DELAY = 1000;

        // Collect Data from an Accelerometer Driven event
        if(event.sensor.getType() == Sensor.TYPE_ACCELEROMETER)
            accelerometer = event.values;
        // collect Data from a Magnetometer Driven Event
        if(event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD)
            geomagnetic = event.values;

        // Check if both sensors caused the event
        if(accelerometer != null && geomagnetic != null)
        {
            float r[] = new float[9];
            float i [] = new float[9];

            boolean foundRotation = SensorManager.getRotationMatrix(r, i, accelerometer, geomagnetic);

            // rotation has occurred
            if(foundRotation)
            {
                float orientation[] = new float[3];
                SensorManager.getOrientation(r, orientation);

                // compute the X-axis rotation angle
                float degree = (float) Math.toDegrees(orientation[0]);

                // Create a rotation animation
                RotateAnimation animation = new RotateAnimation(currentDegree, -degree, Animation.RELATIVE_TO_SELF,
                        0.5f, Animation.RELATIVE_TO_SELF, 0.5f);

                // set the duration of the animation
                animation.setDuration(DELAY);

                // Set animation after the end of the transformation
                animation.setFillAfter(true);

                // Begin the animation
                compassImage.startAnimation(animation);
                currentDegree = -degree;
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }


}

package com.example.rp123.beefingerlab;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.support.constraint.ConstraintLayout;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;

public class MyActivity extends Activity {

    // Activity is split into two threads: Calculating Bee Movement - Background
    // Positioning the Bee - UI Thread

    private Thread calculateThread;

    private ConstraintLayout mainLayout;
    private ImageView beeImageView;
    private ImageView flowerImageView;

    private Flower _Flower; // Declare Flower Object
    private Bee _Bee;       // Declare Bee Object

    private int xLocation;
    private int yLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        // Remove Title
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        // Set the Layout View
        setContentView(R.layout.activity_my);

        mainLayout = findViewById(R.id.constraintLayout);

        // Instantiate the flower and the Bee
        xLocation = 200;
        yLocation = 200;
        addFlower();
        buildBee();

        calculateThread = new Thread(calculateAction);
    }

    private void addFlower()
    {
        // Create LayoutInflater
        LayoutInflater layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        // Specify Flower Position
        int initialXPos = xLocation;
        int initialYPos = yLocation;

        _Flower = new Flower();
        _Flower.setX(initialXPos);
        _Flower.setY(initialYPos);

        // Add the Flower
        flowerImageView = (ImageView) layoutInflater.inflate(R.layout.flower_image, null);
        flowerImageView.setX((float) _Flower.getX());
        flowerImageView.setY((float) _Flower.getY() + 50);
        mainLayout.addView(flowerImageView, 0);
    }

    private void buildBee()
    {
        // Create a layout inflater to add visual views to the layout
        LayoutInflater layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        // Set bee location
        int initialXPos = xLocation;
        int initialYPos = yLocation;

        int proportionalVelocity = 10;
        _Bee = new Bee();
        _Bee.setX(initialXPos);
        _Bee.setY(initialYPos);
        _Bee.setVelocity(proportionalVelocity);

        // Add the bee
        beeImageView = (ImageView) layoutInflater.inflate(R.layout.bee_image, null);
        beeImageView.setX((float) _Bee.getX());
        beeImageView.setY((float) _Bee.getY());
        mainLayout.addView(beeImageView, 0);
    }

    @Override
    protected void onResume() {
        calculateThread.start();
        super.onResume();
    }

    @Override
    protected void onPause() {
        finish();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        finish();
        super.onDestroy();
    }

    private Runnable calculateAction = new Runnable() {
        private static final int DELAY = 200;
        @Override
        public void run() {
            try{
                while(true)
                {
                    _Bee.move(xLocation, yLocation);
                    Thread.sleep(DELAY);
                    threadHandler.sendEmptyMessage(0);
                }
            } catch(InterruptedException e){
                e.printStackTrace();
            }
        }
    };

    // Handler that updates the bee between sleep delays
    public Handler threadHandler = new Handler()
    {
        public void handleMessage(android.os.Message msg)
        {
            // Set the Bee at the correct XY Location
            beeImageView.setX((float) _Bee.getX());
            beeImageView.setY((float) _Bee.getY());
        }
    };

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        // Identify the touch action being performed
        int touchAction = event.getActionMasked();

        // Respond to possible touch events
        switch(touchAction)
        {
            // Bee finds a motionless finger
            case MotionEvent.ACTION_DOWN:
                xLocation = (int) event.getX();
                yLocation = (int) event.getY();
                break;
            // Bee returns to the flower when the finger is removed
            case MotionEvent.ACTION_UP:
                xLocation = _Flower.getX();
                yLocation = _Flower.getY();
                break;
            // Bee follows a moving finger
            case MotionEvent.ACTION_MOVE:
                xLocation = (int) event.getX();
                yLocation = (int) event.getY();
        }

        // Returns a true after handling the touch action event
        return true;
    }
}

package com.example.rp123.beefingerlab;

/**
 * Created by rp123 on 4/19/2018.
 */

public class Flower {
    // Declare properties
    private int _X;
    private int _Y;

    public void setX(int x)
    {
        _X = x;
    }

    public int getX()
    {
        return _X;
    }

    public void setY(int y)
    {
        _Y = y;
    }

    public int getY()
    {
        return _Y;
    }

}

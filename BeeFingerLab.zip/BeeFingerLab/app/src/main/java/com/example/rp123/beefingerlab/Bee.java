package com.example.rp123.beefingerlab;

/**
 * Created by rp123 on 4/19/2018.
 */

public class Bee {
    // Declare properties
    private int _X;
    private int _Y;
    private int _Velocity;


    // Declare Getters and Setters
    public void setVelocity(int velocity)
    {
        _Velocity = velocity;
    }

    public int getVelocity()
    {
        return _Velocity;
    }

    public void setX(int x)
    {
        _X = x;
    }

    public int getX()
    {
        return _X;
    }

    public void setY(int y)
    {
        _Y = y;
    }

    public int getY()
    {
        return _Y;
    }

    // Method to move the bee across the screen
    public void move(int destinationX, int destinationY)
    {
        int distX = destinationX - _X;
        int distY = destinationY - _Y;
        _X += distX / _Velocity;
        _Y += distY / _Velocity;
    }



}

package com.example.rp123.stopwatch;

/**
 * Created by rp123 on 4/5/2018.
 */

public class WatchTime {
    // Time Variables
    private long _startTime;
    private long _timeUpdate;
    private long _storedTime;

    public WatchTime()
    {
        _startTime = 0L;
        _timeUpdate = 0L;
        _storedTime = 0L;
    }

    public void resetWatchTime()
    {
        _startTime = 0L;
        _storedTime = 0L;
        _timeUpdate = 0L;
    }

    public void setStartTime(long startTime)
    {
        _startTime = startTime;
    }

    public long getStartTime()
    {
        return _startTime;
    }

    public void setTimeUpdate(long timeUpdate)
    {
        _timeUpdate = timeUpdate;
    }

    public long getTimeUpdate()
    {
        return _timeUpdate;
    }

    public void addStoredTime(long timeInMilliSeconds)
    {
        _storedTime += timeInMilliSeconds;
    }

    public long getStoredTime()
    {
        return _storedTime;
    }
}

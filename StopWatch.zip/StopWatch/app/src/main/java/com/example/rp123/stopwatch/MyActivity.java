package com.example.rp123.stopwatch;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MyActivity extends Activity {

    // Field level UI variables
    private TextView timeDisplay;
    private Button startButton;
    private Button stopButton;
    private Button resetButton;

    // Field level time variables
    private WatchTime watchTime;
    private long timeInMilliseconds = 0L;

    // Field level Handler for the Thread Element
    private Handler _Handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);

        // Set variable references to UI elements
        timeDisplay = findViewById(R.id.textView);
        startButton = findViewById(R.id.startButton);
        stopButton = findViewById(R.id.stopButton);
        resetButton = findViewById(R.id.resetButton);

        // Disable Stop Button and Reset Button
        stopButton.setEnabled(false);
        resetButton.setEnabled(false);

        // Instantiate Watchtime Object
        watchTime = new WatchTime();

        // Instantiate new Handler object
        _Handler = new Handler();
    }

    public void startTimer(View view)
    {
        // Disable Start button and Enable Stop Button
        stopButton.setEnabled(true);
        startButton.setEnabled(false);
        resetButton.setEnabled(false);

        // Set Start Time and Call the Custom Handler
        watchTime.setStartTime(SystemClock.uptimeMillis());
        _Handler.postDelayed(updateTimerRunnable, 20);
    }

    private Runnable updateTimerRunnable = new Runnable() {
        @Override
        public void run() {
            // Compute Time Difference
            timeInMilliseconds = SystemClock.uptimeMillis() - watchTime.getStartTime();
            watchTime.setTimeUpdate(watchTime.getStoredTime() + timeInMilliseconds);
            int time = (int) (watchTime.getTimeUpdate() / 1000);

            // Compute Minutes, Seconds, and Milliseconds
            int minutes = time / 60;
            int seconds = time % 60;
            int milliseconds = (int) (watchTime.getTimeUpdate() % 1000);

            // Display the time in the Textview
            timeDisplay.setText(String.format("%02d", minutes) + ":" + String.format("%02d", seconds) + ":"
            + String.format("%02d", milliseconds));

            _Handler.postDelayed(this, 0);
        }
    };

    public void stopTimer(View view)
    {
        // Disable the Stop Button and Enable start Button
        stopButton.setEnabled(false);
        startButton.setEnabled(true);
        resetButton.setEnabled(true);

        // Update the stored time value
        watchTime.addStoredTime(timeInMilliseconds);

        // Handler Clears the Message Queue
        _Handler.removeCallbacks(updateTimerRunnable);

    }

    public void resetTimer(View view)
    {
        resetButton.setEnabled(false);
        watchTime.resetWatchTime();
        timeInMilliseconds = 0L;
        int minutes = 0;
        int seconds = 0;
        int milliseconds = 0;

        // Display the time in the TextView
        timeDisplay.setText(String.format("%02d", minutes) + ":" + String.format("%02d", seconds) + ":"
                + String.format("%02d", milliseconds));
    }
}

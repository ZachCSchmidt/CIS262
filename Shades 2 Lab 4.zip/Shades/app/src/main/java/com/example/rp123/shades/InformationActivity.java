package com.example.rp123.shades;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.widget.TextView;

/**
 * Created by rp123 on 3/9/2018.
 */

public class InformationActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        // Ensure orientation has switched to landscape mode
        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE)
        {
            finish();
            return;
        }

        // Set the layout for the specified activity
        setContentView(R.layout.information_fragment);

        // Display the up icon in action bar

        getActionBar().setDisplayHomeAsUpEnabled(true);

        // Return the intent that started this activity
        Intent intent = getIntent();
        String shadeInfo = intent.getStringExtra("Information");

        TextView information = findViewById(R.id.textView1);
        information.setText(shadeInfo);
    }
}

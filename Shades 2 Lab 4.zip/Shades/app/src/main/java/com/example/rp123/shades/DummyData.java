package com.example.rp123.shades;

import java.util.List;

/**
 * Created by rp123 on 3/9/2018.
 */

public class DummyData {
    // Some data for the ListView
    // Sample of shades and their meaning in an array.

    public static String[] shades_names_array = {"Tan", "Black", "Blue", "Brown", "Gold",
    "Lavender", "Orange", "Pink", "Red", "White", "Yellow"};


    public static String [] shade_details_array = {"Tan is a neutral color with a bit of warmth.",
    "Black is the absence of color.", "Blue is calming. It can be strong and steadfast.",
    "Brown is a warm neutral color.", "Gold is a precious metal", "Lavender is delicate considered" +
            "precious.", "Orange is a stimulant", "Pink can create physical weakness in people.",
    "Red is hot. It's a strong color.", "White is often associated with hospitals.", "Yellow is sunshine."};
}

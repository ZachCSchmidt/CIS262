package com.example.rp123.shades;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class MyActivity extends Activity implements
        ListFragment.OnItemSelectedListener {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);
    }

    @Override
    public void onShadeItemSelected (String link)
    {
        // Check if information fragment exists in layout
        InformationFragment informationFragment = (InformationFragment)
                getFragmentManager().findFragmentById(R.id.fragment2);

        // Check if a two pane configuration is being displayed
        if(informationFragment != null && informationFragment.isInLayout()){
            informationFragment.setText(link);
        }

        // Otherwise a single pane configuration
        else{
            // Activate Information Activity if Information Fragment doesn't exit in this layout
            Intent intent = new Intent(this, InformationActivity.class);
            intent.putExtra("Information", link);
            startActivity(intent);
        }
    }
}

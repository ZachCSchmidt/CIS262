package com.example.rp123.shades;

import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by rp123 on 3/9/2018.
 */

public class ListFragment extends Fragment {

    // Field Level Variables
    private OnItemSelectedListener listener;
   List<String> shadelist; // The list of colors
   List<String> shadeNameDetail; // The list of details


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        //View view = inflater.inflate(R.layout.list_fragment, container,false);

        shadelist = new ArrayList<String>(Arrays.asList(DummyData.shades_names_array));
        shadeNameDetail = new ArrayList<String>(Arrays.asList(DummyData.shade_details_array));

        // Populate the List_item_shade xml textview field with the list of colors
        final ArrayAdapter<String> _ShadeAdapter = new ArrayAdapter<String>(getActivity(), R.layout.list_item_shade,
                R.id.list_item_shade_textview, shadelist);

        View rootView = inflater.inflate(R.layout.list_fragment, container, false);

        // Show the array of colors in the listview
        ListView listView = rootView.findViewById(R.id.listview_shades);
        listView.setAdapter(_ShadeAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l){
                String shadeIndexString = _ShadeAdapter.getItem(i);
                String information = shadeIndexString + "\n\n\n" + shadeNameDetail.get(i);
                updateDetail(information);
            }
        });

        return rootView;



       /* Button button1 = view.findViewById(R.id.plum_button);
        button1.setOnClickListener(ShadeChangeListener);

        Button button2 = view.findViewById(R.id.blue_button);
        button2.setOnClickListener(ShadeChangeListener);

        Button button3 = view.findViewById(R.id.gold_button);
        button3.setOnClickListener(ShadeChangeListener);

        return view;
        */
    }


    /*private OnClickListener ShadeChangeListener = new OnClickListener() {

        public void onClick(View view) {
            String description = (String) view.getContentDescription();
            information = description;
            updateDetail();

        }
    };*/

    public interface OnItemSelectedListener{
        public void onShadeItemSelected(String link);
    }

    @Override
    public void onAttach(Activity activity)
    {
        super.onAttach(activity);
        if(activity instanceof OnItemSelectedListener){
            listener = (OnItemSelectedListener) activity;
        }
        else{
            throw new ClassCastException(activity.toString() + " must implement MyListFragment.OnItemSelectedListener");
        }
    }

    public void updateDetail(String information)
    {
        listener.onShadeItemSelected(information);
    }
}

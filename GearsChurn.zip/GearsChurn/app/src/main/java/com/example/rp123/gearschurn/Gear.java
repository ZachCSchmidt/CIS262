package com.example.rp123.gearschurn;

/**
 * Created by rp123 on 3/22/2018.
 */

public class Gear {
    // Declare Fields

    private int _StartDegree;
    private int _EndDegree;

    public Gear()
    {
        _StartDegree = 0;
        _EndDegree = 0;
    }

    // Getters and Setters

    public void setStartDegree(int startDegree)
    {
        _StartDegree = startDegree;
    }

    public int getStartDegree()
    {
        return _StartDegree;
    }

    public void setEndDegree(int endDegree)
    {
        _EndDegree = endDegree;
    }

    public int getEndDegree()
    {
        return _EndDegree;
    }

}
